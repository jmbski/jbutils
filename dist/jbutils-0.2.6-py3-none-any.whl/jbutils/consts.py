"""Constant variables for the jbutils library"""

from typing import ClassVar

LOG_FMT_ID = "[%(name)s::%(module)s::%(origFunc)s]"
LOG_FMT_RICH = f"{LOG_FMT_ID} %(message)s"
LOG_FMT_STND = f"%(asctime)s {LOG_FMT_ID} [%(levelname)s] %(message)s"


class RuntimeGlobals:
    """Reference class for various global values to use at runtime"""

    debug: ClassVar[bool] = False
    """ Toggle to enable developer level debugging output """

    verbose: ClassVar[bool] = False
    """ Toggle to enable general level extra log output """

    use_rich_console: ClassVar[bool] = True
    """ Toggle this if you ever want to force-disable Rich console output. """
